<?php

	include_once "includes/database.php";
	include_once "includes/functions.php";
	include_once "includes/showheader.php";
	include_once "includes/showfooter.php";
	session_destroy();
	header( "refresh:0;url=items.php" );
	
?>
