<?php
ob_start();

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/showheader.php";
//include_once "includes/sidebar.php";

if(isset($_GET['add']) AND isset($_SESSION['usertype']) AND ($_SESSION['usertype']=='student' OR $_SESSION['usertype']=='employee' ) ){
	include_once "includes/add_to_order.php";
}elseif(isset($_GET['add']) AND !isset($_SESSION['usertype'])){
	include_once "includes/loginUser.php";
}elseif(isset($_GET['delete']) ){
	include_once "includes/delete_item_from_order.php";
}elseif(isset($_GET['payment']) AND  ($_SESSION['usertype']=='student' OR $_SESSION['usertype']=='employee' ) ){
	include_once "includes/payment_order.php";	
}elseif(!isset($_SESSION['usertype'])){
	include_once "includes/loginUser.php";
}else{
	include_once "includes/show_order.php";
}

include_once "includes/showfooter.php";

ob_end_flush();

?>
