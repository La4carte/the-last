<?php

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/header.php";

if(adminChecker()==FALSE){
		include_once "includes/login.php";
	}else{
	if(isset($_GET['items']))	
			include_once "includes/items.php";		
		elseif(isset($_GET['additem']))
			include_once "includes/additem.php";				
		elseif(isset($_GET['edititem']))
			include_once "includes/edititem.php";				
		elseif(isset($_GET['removeitem']))
			include_once "includes/deleteitem.php";	
		elseif(isset($_GET['orders']))
			include_once "includes/admin_orders.php";
		elseif(isset($_GET['order']))
			include_once "includes/order_list.php";
		elseif(isset($_GET['delivered']))
			include_once "includes/delivered.php";
		elseif(isset($_GET['delivery']))
			include_once "includes/delivery.php";
		elseif(isset($_GET['categories']))
			include_once "includes/categories.php";
		elseif(isset($_GET['addcategory']))
			include_once "includes/addcategory.php";
		elseif(isset($_GET['editcategory']))
			include_once "includes/editcategory.php";
		elseif(isset($_GET['removecategory']))
			include_once "includes/removecategory.php";
		else	
			include_once "includes/admin_page.php";	
		
	}
	
include_once "includes/footer.php";

?>
