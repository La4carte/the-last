<?php
ob_start();

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/showheader.php";
include_once "includes/sidebar.php";
include_once "includes/loginUser.php";

include_once "includes/showfooter.php";
ob_end_flush();

?>
