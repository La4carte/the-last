<?php

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/header.php";

if(deliveryChecker()==FALSE){
		include_once "includes/loginDelivery.php";
	}elseif(deliveryChecker()==TRUE){
		if(isset($_GET['delivery']))
			include_once "includes/delivery.php";
		elseif(isset($_GET['order']))
			include_once "includes/order_list.php";
		else	
			include_once "includes/delivery_orders.php";	
	}
	
include_once "includes/footer.php";

?>
