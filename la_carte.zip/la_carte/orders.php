<?php
ob_start();

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/showheader.php";

if(loginChecker()==FALSE){
		include_once "includes/loginUser.php";
}else{
	if(isset($_GET['order']))
		include_once "includes/order_user.php";
	else
		include_once "includes/user_orders.php";
}

include_once "includes/showfooter.php";

ob_end_flush();

?>
