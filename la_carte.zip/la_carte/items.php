<?php

include_once "includes/database.php";
include_once "includes/functions.php";
include_once "includes/showheader.php";
include_once "includes/sidebar.php";
include_once "includes/showitems.php";
include_once "includes/showfooter.php";

?>
