<style>


.centerdiv {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-right:25%;
  margin-left:25%;
  margin-top:50px;
}



h2 {
	text-align:center;
}


.danger {
  background-color: #ffdddd;
  border-left: 6px solid #f44336;
  font-size:18;
}

.success {
  background-color: #ddffdd;
  border-left: 6px solid #4CAF50;
  font-size:18;

}

</style>

<h2>Delete</h2>
<div>
	<?php 
	
	$id	=	$_GET['delete'];
	unset($_SESSION['cart'][$id]);
	header( "refresh:3;url=order.php");
	echo ok("Delete the product from cart");
?>

</div>
