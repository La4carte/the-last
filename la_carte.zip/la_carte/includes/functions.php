<?php

function sign_admin($usename,$password ){
global $connection ;
	//  
	$sql	=	"SELECT * FROM `admin_information` WHERE ADMIN_USERNAME='$usename' AND ADMIN_PASSWORD='$password' LIMIT 1";
	$result	=	$connection->query($sql);
	$numrows=	0;
	$numrows = $result->num_rows;
	if($numrows==1){
		$row	=	mysqli_fetch_assoc($result);
		$_SESSION['userid']		=	$row['ADMIN_ID'];
		$_SESSION['username']	=	$row['ADMIN_USERNAME'];
		$_SESSION['userpassword']	=	$row['ADMIN_PASSWORD'];
		$_SESSION['usertype']	=	'administrator';
		
		return TRUE;
	}else{
		return FALSE;
	}

}

function sign_student($usename,$password ){
global $connection ;
	//  
	$sql	=	"SELECT * FROM `student_information` WHERE STUDENT_USERNAME='$usename' AND STUDENT_PASSWORD='$password' LIMIT 1";
	$result	=	$connection->query($sql);
	$numrows=	0;
	$numrows = $result->num_rows;
	if($numrows==1){
		$row	=	mysqli_fetch_assoc($result);
		$_SESSION['userid']		=	$row['STUDENT_ID'];
		$_SESSION['username']	=	$row['STUDENT_USERNAME'];
		$_SESSION['userpassword']	=	$row['STUDENT_PASSWORD'];
		$_SESSION['usertype']	=	'student';
		
		return TRUE;
	}else{
		return FALSE;
	}

}

function sign_employee($usename,$password ){
global $connection ;
	//  
	$sql	=	"SELECT * FROM `employee_information` WHERE EMPLOYEE_USERNAME='$usename' AND EMPLOYEE_PASSWORD='$password' LIMIT 1";
	$result	=	$connection->query($sql);
	$numrows=	0;
	$numrows = $result->num_rows;
	if($numrows==1){
		$row	=	mysqli_fetch_assoc($result);
		$_SESSION['userid']		=	$row['EMPLOYEE_ID'];
		$_SESSION['username']	=	$row['EMPLOYEE_USERNAME'];
		$_SESSION['userpassword']	=	$row['EMPLOYEE_PASSWORD'];
		$_SESSION['usertype']	=	'employee';
		
		return TRUE;
	}else{
		return FALSE;
	}

}

function sign_delivery($usename,$password ){
global $connection ;
	//  
	$sql	=	"SELECT * FROM `delivry_information` WHERE DELIVRY_USERNAME='$usename' AND DELIVRY_PASSWORD='$password' LIMIT 1";
	$result	=	$connection->query($sql);
	$numrows=	0;
	$numrows = $result->num_rows;
	if($numrows==1){
		$row	=	mysqli_fetch_assoc($result);
		$_SESSION['userid']		=	$row['DELIVRY_ID'];
		$_SESSION['username']	=	$row['DELIVRY_USERNAME'];
		$_SESSION['userpassword']	=	$row['DELIVRY_PASSWORD'];
		$_SESSION['usertype']	=	'delivery';
		
		return TRUE;
	}else{
		return FALSE;
	}

}

function notok($msg){
echo '<div class="danger">'.$msg.'</div>';	
}

function ok($msg){
echo '<div class="success">'.$msg.'</div>';	
}


function deliveryChecker(){
	if( isset($_SESSION['usertype']) AND $_SESSION['usertype']=='delivery')
		return TRUE;
	else
		return FALSE;
}

function adminChecker(){
	if( isset($_SESSION['usertype']) AND $_SESSION['usertype']=='administrator')
		return TRUE;
	else
		return FALSE;
}


function loginChecker(){
	if( isset($_SESSION['usertype']))
		return TRUE;
	else
		return FALSE;
}



function update($table,$bcal,$bvalue,$col,$value){
global $connection;
		$sql	=	"UPDATE $table SET $col='$value' where $bcal='$bvalue' ";
		$insert		=	$connection->query($sql);	

}


function valueIs($table,$bcol,$bvalue,$col){
global $connection; 
		$sql	=	"SELECT $col FROM $table where $bcol='$bvalue' ";
		$query	=	$connection->query($sql);	
		$row	=	mysqli_fetch_assoc($query);
		return $row[$col];
}

function delete($table,$bcal,$bvalue){
global $connection;
		$sql	=	"delete from $table where $bcal='$bvalue' ";
		$insert		=	$connection->query($sql);	

}

function make_order($method,$STATE){
	global $connection;
	$user_id	=	$_SESSION['userid'];
	$usertype	=	$_SESSION['usertype'];
	$sql	=	"INSERT INTO `orders` (`ORDER_ID`, `user_id`, `user_type`, `ORDER_DATE`, `ORDER_STATE`, `DELIVRY_ID`, `PAY_METHOD`)
	 VALUES (NULL, '$user_id', '$usertype', CURRENT_TIMESTAMP, '$STATE', NULL ,'$method')  ";
	  mysqli_query($connection,$sql) or die(mysqli_error($connection));
	 $last_id = $connection->insert_id;
	return $last_id;
}

function add_to_order($order_id,$ITEM_ID,$QUANTITY,$price){
global $connection;
	$sql	=	"INSERT INTO `order_item` (`ORDER_ITEM_ID`, `ORDER_ID`, `ITEM_ID`, `QUANTITY`, `TOTAL_PRICE`) 
	VALUES (NULL, '$order_id', '$ITEM_ID', '$QUANTITY', '$price') ";
	mysqli_query($connection,$sql) or die(mysqli_error($connection));
	
}

?>


