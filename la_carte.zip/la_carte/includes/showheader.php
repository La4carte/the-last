<!doctype html>
<html>
    <head>
      <link href="header.css" rel="stylesheet" type="text/css">
      <link href="footerandheader.css" rel="stylesheet" type="text/css">
		<link href="stylee.css" rel="stylesheet" type="text/css">
		<title>La Cart</title>
      </head>
      
      <header> 
        <img src="logo.jpg.jpeg" alt="" width="200" height="156" id="logoo" class="center "/>
          
      <div class="profileLogo"> 
        
          <p class="logoPlaceholder"><span>La Carte</span></p>

        
        <div id="headerLinks">
			<hr style="width:120%;text-align:center;margin-left:0">
         <?php if(loginChecker()==FALSE) { ?> 
          <a href="login.php" title="Login/Register">Login/Register</a>
         <?php }else{ ?>
          <a href="order.php" title="Cart">Cart</a>
          <a href="orders.php" title="Cart">Your Orders</a>
          <a href="out.php" title="Login/Register">Out</a>
         <?php } ?>
        </div>
      </header>
