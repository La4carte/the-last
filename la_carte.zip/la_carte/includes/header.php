
<html lang="ar" dir="rtl">
	<head>
		<title>الإدارة</title>
		<meta charset="utf-8" >
		<link href="admin.css" rel="stylesheet" >
		<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	</head>
	<body>
<div class="topnav" id="myTopnav">

<?php if(adminChecker()==TRUE){ ?>
  <a href="admin.php">الإدارة</a>
<?php } ?>
<?php if(deliveryChecker()==TRUE){ ?>
  <a href="delivery.php">الرئيسية</a>
<?php } ?>
<?php if(loginChecker()==TRUE){ ?>
  <a href="out.php">الخروج</a>
<?php } ?>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
