<?php
$userid	=	$_SESSION['userid'];	
?>
<div>
<h1>القطع</h1>

<a href="?additem" ><button class="btn info">إضافة قطعة</button></a>


		<table >
			<tr>
				<th>الكفيتيريا</th>
				<th>المنتج</th>
				<th>القسم</th>
				<th>السعر</th>
				<th>الوصف</th>
				<th>الكمية</th>
				<th>الصورة</th>
				<th>التعديل</th>
				<th>الحذف</th>
			</tr>
<?php 
	$sql	=	"SELECT * FROM `items` ORDER BY ITEM_ID DESC  ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
?>			
			<tr>
				<td><?php echo valueIs("cafeteria_information","CAFETERIA_ID",$row['cafeteria_id'],"CAFTERIA_USERNAME");?></td>
				<td><?php echo $row['ITEM_NAME'];?></td>
				<td><?php echo valueIs("items_category","category_id",$row['category_id'],"category_title");?></td>
				<td><?php echo $row['ITEM_PRICE'];?></td>
				<td><?php echo nl2br($row['ITEM_DWSCREPTION']);?></td>
				<td><?php echo $row['ITEM_QUANTITY'];?></td>
				<td><img src="<?php echo $upload_folder.$row['ITEM_IMG'];?>" width="100px"></td>
				<td><a href="?edititem=<?php echo $row['ITEM_ID'];?>">تعديل</a></td>
				<td><a href="?removeitem=<?php echo $row['ITEM_ID'];?>">حذف</a></td>
			</tr>
			
<?php } ?>

		</table>

</div>
