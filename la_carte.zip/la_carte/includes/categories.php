<div class="centerdiv">
<h1>الأقسام للمنتجات</h1>

<a href="?addcategory" ><button class="btn info">إضافة قسم</button></a>


		<table >
			<tr>
				<th>إسم القسم</th>
				<th>التعديل</th>
				<th>الحذف</th>
			</tr>
<?php 
	$sql	=	"SELECT * FROM `items_category` ORDER BY category_id DESC  ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
?>			
			<tr>
				<td><?php echo $row['category_title'];?></td>
				<td><a href="?editcategory=<?php echo $row['category_id'];?>">تعديل</a></td>
				<td><a href="?removecategory=<?php echo $row['category_id'];?>">حذف</a></td>
			</tr>
			
<?php } ?>

		</table>

</div>
