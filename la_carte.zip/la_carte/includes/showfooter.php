  <footer> 
    <!-- This is the footer with default 3 divs -->
    <div>
</div>
</body>
</html>
      <p>&nbsp;</p>
    </div>
    <div>
      <p>@ all copy right to La Carte </p>
    </div>
    <div class="footerlinks">
     
    </div>
  </footer>
  <style>
    footer {
	display: block;
	text-align: center;
	font-family: sans-serif;
}
footer .footerlinks {
	margin-top: -15px;
}
footer .footerlinks p {
	display: inline;
}
#mainWrapper footer div {
	width: 100%;
	margin-left: -16px;
	text-align: justify;
	padding-bottom: 16px;
	overflow: auto;
}
.footerlinks p a {
	padding-top: 0px;
	padding-bottom: 0px;
	display: inline;
	padding-right: 35px;
}
/* Footer region */
#mainWrapper footer {
	padding-left: 16px;
	overflow: hidden;
}
#mainWrapper footer .footerlinks {
	float: none;
	width: 100%;
	position: relative;
	top: 17px;
	clear: both;
	text-align: center;
	left: 0%;
	padding-bottom: 19px;
}
/* Container for each footer divisions */
#mainWrapper footer div {
	width: 44%;
	text-align: justify;
	font-size: 15px;
}
#mainWrapper footer div {
	width: 27%;
	float: left;
	padding-left: 4%;
	padding-right: 2%;
	color: rgba(255,255,255,1.00);
	text-align: justify;
}
/* Links in footer */
footer div a {
	color: rgba(146,146,146,1.00);
	display: block;
	text-decoration: none;
	text-align: center;
}
footer {
	clear: both;
	overflow: auto;
	background-color: #373543;
	font-family: source-sans-pro, sans-serif;
	font-style: normal;
	font-weight: 200;
	line-height: 1.8;
	padding-top: 22px;
	padding-left: 22px;
	text-align: center;
	padding-bottom: 22px;
	padding-right: 22px;}
@media (max-width: 1004px){
}
  </style>
</html>
