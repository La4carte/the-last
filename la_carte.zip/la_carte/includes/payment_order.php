<style>

input, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 4px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 20px;
  font-weight:bold;
  font-family:arial;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  
}


.centerdiv {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-right:25%;
  margin-left:25%;
  margin-top:50px;
}

textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 4px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
  margin:8px 0;
}

label {
	font-size: 19px;
}

h1 {
	text-align:center;
}


.danger {
  background-color: #ffdddd;
  border-left: 6px solid #f44336;
  font-size:18;
}

.success {
  background-color: #ddffdd;
  border-left: 6px solid #4CAF50;
  font-size:18;

}

</style>


<h2>Payment</h2>

<?php  
	if(isset($_POST['do'])){
		
		if(isset($_POST['Receipt']) AND !empty($_POST['Receipt'])){
			$STATE	=	$_POST['Receipt'];
		}else{
			$STATE	=	"إستلام من الكفيتيريا";
		}
		
		$order_id	=	make_order($_POST['method_id'],$STATE);
			foreach($_SESSION['final'] AS $ITEM_ID=>$quantity){
					$price	=	(float)valueIs("items","ITEM_ID",$ITEM_ID,"ITEM_PRICE")*(int)$quantity;
					add_to_order($order_id,$ITEM_ID,$quantity,$price);
			}
			
		
			
		unset($_SESSION['final']);
		unset($_SESSION['cart']);
		unset($_SESSION['q']);	
			 
			 echo ok("Success added your order to system");
			 header( "refresh:2;url=items.php" );
				die();	
	}
?>

<div>
	<form action="" method="POST">

	  <label>Total</label>
	  <input type="text"  value="<?php echo $_SESSION['final_price'];?>"  disabled >

	  <label>Selete pay method </label>
	  <select name="method_id" required >
		<option value="" >Please select</option>
		<option value="كـاش عند الإستلام" >Cash</option>
		<option value="مدى عند الإستلام" >Mada</option>
	 </select>

<?php if($_SESSION['usertype']	==	'employee') {?>		
	  <label>Receipt from</label>
	  <select name="Receipt" required >
		<option value="" >Please select</option>
		<option value="Receipt from the cafeteria" >Receipt from the cafeteria</option>
		<option value="Receipt from your office" >Receipt from your office</option>
	  </select>
<?php } ?>
	  	  <input type="submit" name="do" value="Confirm">
	</form> 
</div>
