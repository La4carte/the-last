	 <div id="content">
    <section class="sidebar"> 
      <!-- This adds a sidebar with 1 searchbox,2 menusets, each with 4 links -->
      <input type="text"  id="search" value="search">
      <div id="menubar">
     <nav class="menu">
          <h2><a href="?" >MENU</a></h2>
          <!-- Title for menuset 2 -->
          <hr>
          <ul>
			  
<?php 
	$sql	=	"SELECT * FROM `items_category` ORDER BY category_id DESC  ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
	echo ' <li><b><a href="?category='.$row['category_id'].'" title="Link">'.$row['category_title'].'</a></b></li>';
}
?>	
           

          </ul>
			<br> 
			<br> 
			<br> 
			<br> 
    <a href="order.php" style="
	text-align:center ; font-size:20x;color: #01DFA5;background:linear-gradient(to bottom, #3cc195 5%, #a8e1c8 100%);
	background-color:#3cc195;
	border-radius:28px;
	border:1px solid #ffffff;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	width: 60%;
	font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', 'serif';
	font-size:17px;
	padding:16px 31px;
	text-decoration:none;
	text-shadow:0px 1px 0px #455443;">Cart </a>
        </nav>
      </div>
    </section>
