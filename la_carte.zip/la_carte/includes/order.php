<?php $id = (int)$_GET['id'];?>
<h2>عناصر الطلب</h2>
<div class="cont">
	<table style="width:100%;" border=1 >
	  <tr>
		<th>مسمى الكتاب</th>
		<th>ISBN10</th>
		<th>لغة الكتاب</th>
		<th>سعر الكتاب</th>
		<th>قسم الكتاب</th>
		<th>صورة الغلاف</th>
		<th>عدد القطع</th>
		<th>الإجمالي</th>
	  </tr>

	<?php 	
		$result	=	$db->query("SELECT * FROM `order_items` where order_id='$id'  ");
		while ($row	=	mysqli_fetch_assoc($result)){
	 ?>
	  <tr >
		<td><?php echo show_data('ebooks','ebook_title','eBook_id',$row['eBook_id']);?> </td>
		<td><?php echo show_data('ebooks','eBook_ISBN10','eBook_id',$row['eBook_id']);?> </td>
		<td><?php echo show_data('ebooks','eBook_language','eBook_id',$row['eBook_id']);?> </td>
		<td><?php echo show_data('ebooks','ebook_pirce','eBook_id',$row['eBook_id']);?> </td>
		<td><?php echo show_data('category','category_title','category_id',show_data('ebooks','category_id','eBook_id',$row['eBook_id']));?></td>
		<td><a target="_blank" href="<?php echo $upload_folder.show_data('ebooks','cover_page_img','eBook_id',$row['eBook_id']);?>"><img src="<?php echo $upload_folder.show_data('ebooks','cover_page_img','eBook_id',$row['eBook_id']);?>" class="Thumb"></a></td>
		<td><?php echo $row['eBook_quantity'];?> </td>
		<td><?php echo $row['eBook_price'];?> </td>

	  </tr>
<?php
 
}  ?>

	  <tr >
		<th>العنوان</th>
		<th colspan=7><?php echo show_data('stds','address','std_id',show_data('orders','std_id','order_id',$id));?></th>
	  </tr>	  
	  <tr >
		<th>الدفع</th>
		<th colspan=7><?php echo show_data('methods','method_title','method_id',show_data('orders','method_id','order_id',$id));?></th>
	  </tr>	  
	  <tr >
		<th>الإجمالي</th>
		<th colspan=7><?php echo show_data('orders','order_total','order_id',$id);?></th>
	  </tr>	  
	</table> 
	</div>
