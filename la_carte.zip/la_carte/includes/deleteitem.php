<div class="centerdiv" >
<h1>حذف قطعة</h1>

<?php
		$id	=	(int)$_GET['removeitem'];
		delete("items","ITEM_ID",$id);
		header("refresh:3; url=admin.php?items");
		ok("تم الحذف بنجاح");
		exit();
?>
</div>
