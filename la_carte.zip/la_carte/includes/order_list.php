<?php $id	=	$_GET['order'];?>
<div class="centerdiv"  style="margin-top:20px;">
<h1>قائمة الطلب</h1>

		<table >
			<tr>
				<th>المنتج</th>
				<th>الكمية</th>
				<th>السعر الإجمالي</th>
			</tr>
<?php 
$sum	=	0;
	$sql	=	"SELECT * FROM `order_item` where ORDER_ID='$id' ORDER BY ORDER_ID DESC ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
	$sum= $sum+$row['TOTAL_PRICE'];
?>			
			<tr>
				<td><?php echo valueIs("items","ITEM_ID",$row['ITEM_ID'],"ITEM_NAME");?></td>
				<td><?php echo $row['QUANTITY'];?></td>
				<td><?php echo $row['TOTAL_PRICE'];?></td>
			</tr>
			
<?php } ?>
			<tr>
				<th colspan=2>المطلوب من العميل</th>
				<th><?php echo $sum;?></th>
			</tr>
		</table>

</div>
