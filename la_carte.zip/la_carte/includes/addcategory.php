<div class="centerdiv" >
		<h1>إضافة قسم</h1>
<?php
	if(isset($_POST['go'])){

	$category_title	=	$_POST['category_title'];
	
				$sql	=	"INSERT INTO `items_category` (`category_id`, `category_title`) VALUES (NULL, '$category_title')  ";
				$connection->query($sql);
				ok("تم إضافة القسم بنجاح وجاري تحويلك");
				header("refresh:3; url=admin.php?categories");
				exit();

	
		
	}
?>

		
		<form action="" method="POST">
		
			
			<label>مسمى القسم</label>
			<input type="text" name="category_title" required >
						
			
			<input type="submit" name="go"  value="أضف" >
		</form>
		</div>
