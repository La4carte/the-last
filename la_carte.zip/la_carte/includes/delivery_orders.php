<div class="centerdiv"  style="margin-top:20px;">
<h1>قائمة الطلبات</h1>

		<table >
			<tr>
				<th>المشتري</th>
				<th>قائمة السلة</th>
				<th>الحالة</th>
				<th>تاريخ الطلب</th>
				<th>طريقة الدفع</th>
				<th>التوصيل</th>
			</tr>
<?php 
	$sql	=	"SELECT * FROM `orders` where DELIVRY_ID ='".$_SESSION['userid']."' ORDER BY ORDER_ID DESC ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){

			$table	=	"employee_information";
			$name	=	"EMPLOYEE_NAME";
			$row_id	=	"EMPLOYEE_ID";

?>			
			<tr>
				<td><?php echo valueIs($table,$row_id,$row['user_id'],$name);?></td>
				<td><a href="?order=<?php echo $row['ORDER_ID'];?>">عرض السلة</a></td>
				<td><?php echo $row['ORDER_STATE'];?></td>
				<td><?php echo $row['ORDER_DATE'];?></td>
				<td><?php echo $row['PAY_METHOD'];?></td>
				<td>
					<?php if($row['ORDER_STATE']=='Receipt from your office'){ ?>
						<a href="?delivery=<?php echo $row['ORDER_ID'];?>">أكد التوصيل</a>
					<?php }else{
							echo "تم تسليم الطلب";	
							}
					?>
				</td>
			</tr>
			
<?php } ?>

		</table>

</div>
