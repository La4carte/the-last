<?php
$server 	=	'localhost';
$user 	=	'root';
$pass 	=	'';
$dname 	=	'la_carte';

$connection = new mysqli($server,$user,$pass,$dname);

if ($connection -> connect_errno) {  echo "Failed to connect to MySQL: " . $connection -> connect_error; exit();}

$connection->set_charset("utf8");
session_start();

$upload_folder = "upload/";

?>
