<style>

table {
  border-collapse: collapse;
  width: 100%;
  
}

th, td {
  text-align: center;
  padding: 8px;
 border: 4px solid #ccc;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}

a {
text-decoration:none;
}

input, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 4px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 20px;
  font-weight:bold;
  font-family:arial;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  
}


.con {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-right:25%;
  margin-left:25%;
  margin-top:50px;
}


</style>


<?php $id	=	$_GET['order'];?>
<div class="centerdiv"  style="margin-top:20px;">
<h1>Cart</h1>

		<table >
			<tr>
				<th>Product</th>
				<th>Quantity</th>
				<th>Price</th>
			</tr>
<?php 
$sum	=	0;
	$sql	=	"SELECT * FROM `order_item` where ORDER_ID='$id' ORDER BY ORDER_ID DESC ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
	$sum= $sum+$row['TOTAL_PRICE'];
?>			
			<tr>
				<td><?php echo valueIs("items","ITEM_ID",$row['ITEM_ID'],"ITEM_NAME");?></td>
				<td><?php echo $row['QUANTITY'];?></td>
				<td><?php echo $row['TOTAL_PRICE'];?></td>
			</tr>
			
<?php } ?>
			<tr>
				<th colspan=2>Total Cart</th>
				<th><?php echo $sum;?></th>
			</tr>
		</table>

</div>
