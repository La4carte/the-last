<div class="centerdiv" >
		<h1>تعيين عامل توصيل</h1>
<?php
$id	=	$_GET['delivered'];
	if(isset($_POST['go'])){
		
		$DELIVRY_ID		=	(int)$_POST['DELIVRY_ID'];
		update("orders","ORDER_ID",$id,'DELIVRY_ID',$DELIVRY_ID);

				ok("تم تعيين عامل التوصيل بنجاح");
				header("refresh:3; url=admin.php?orders");
				exit();		
}

?>

		
		<form action="" method="POST"  >
			

			<label>إختر العامل</label>
			  <select  name="DELIVRY_ID" required  >
				<?php 
					$rescom	=	$connection->query("SELECT * FROM `delivry_information` ");
					while ($rowcom	=	mysqli_fetch_assoc($rescom))
						echo '<option value="'.$rowcom['DELIVRY_ID'].'">'.$rowcom['DELIVRY_NAME'].'</option>';
				?>
				
			  </select>
			
			<input type="submit" name="go"  value="عين" >
		</form>
		</div>
