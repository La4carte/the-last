<div class="centerdiv" >
<h1>دخول عامل التوصيل</h1>

<?php
	if( isset($_POST['signin']) AND sign_delivery($_POST['username'],$_POST['userpasword'])==TRUE ){
		
		header("refresh:3; url=?");
		ok("مرحبا بك وجاري تحويلك إلى لوحة التحكم");
		exit();
	}elseif(isset($_POST['signin'])){
		notok("الرجاء التحقق من اسم المستخدم والرقم السري");	
	}

?>



<form action="" method="POST" >
	<label>إسم المستخدم</label>
	<input type="text" name="username" >

	<label>الرقم السري</label>
	<input type="password" name="userpasword" >

	<input type="submit" name="signin"  value="دخول" >
</form>
</div>
