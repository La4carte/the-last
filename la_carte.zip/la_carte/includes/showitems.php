
          <style>
            header {
        text-align: center;
        display: block;
      }
      #headerLinks {
        float: left;
        width: calc( 100% - 139px );
        text-align: right;
        padding-top: 10px;
        padding-bottom: 10px;
        background-color: rgba(255,255,255,1.00);
      }
      /* Links in header */
      #headerLinks a {
        text-decoration: none;
        color: rgba(146,146,146,1.00);
        padding-left: 66px;
        font-size: 14px;
      }
      header .logoPlaceholder span {
        width: 80px;
        height: 22px;
        font-family:  "Times New Roman", Times, serif;
        color: #FFFFFF;
        font-size: 30px;
        font-weight: 700;
        line-height: 53px;
        
      }
      header .profileLogo .logoPlaceholder {
        background-color: #C6EBDA;
        width: 200px;
        text-align: center;
        padding-top: 10px;
        padding-bottom: 10px;
        float: left;
        
      }
          </style>
<section class="mainContent">
      <div class="productRow"><!-- Each product row contains info of 3 elements -->
<?php 
if(isset($_GET['category']) AND !empty($_GET['category']) ){
	$id	=	(int)$_GET['category'];
	$sql	=	"SELECT * FROM `items` WHERE `category_id` ='$id' ORDER BY `ITEM_ID` DESC ";
}else{
	$sql	=	"SELECT * FROM `items` ORDER BY ITEM_ID DESC  ";
}
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
		
?>	    
        <article class="productInfo"><!-- Each individual product description -->
          <div><img alt="sample" src="<?php echo $upload_folder.$row['ITEM_IMG'];?>" alt="" width="250" height="140"></div>
          <p class="price"><?php echo $row['ITEM_PRICE'];?> SR</p>
          <p class="productContent"><?php echo $row['ITEM_NAME'];?></p>
          <a href="order.php?add=<?php echo $row['ITEM_ID'];?>" >
			<input type="button" name="button" value="Add to Cart" class="buyButton">
		 </a>
        </article>
 <?php } ?>
   
      </div>
        <article class="productInfo"><!-- Each individual product description -->
          <div></div>
</article>
      </div>
    </section>
  </div>
