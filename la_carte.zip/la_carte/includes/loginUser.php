<style>

input, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 4px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 20px;
  font-weight:bold;
  font-family:arial;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  
}


.centerdiv {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-right:25%;
  margin-left:25%;
  margin-top:50px;
}

textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 4px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  resize: none;
  margin:8px 0;
}

label {
	font-size: 19px;
}

h1 {
	text-align:center;
}


.danger {
  background-color: #ffdddd;
  border-left: 6px solid #f44336;
  font-size:18;
}

.success {
  background-color: #ddffdd;
  border-left: 6px solid #4CAF50;
  font-size:18;

}

</style>
<div class="centerdiv" >
<h1>Login</h1>

<?php
	if( isset($_POST['signin']) AND $_POST['type']=='student' AND sign_student($_POST['username'],$_POST['userpasword'])==TRUE ){
		
		header("refresh:3; url=items.php");
		ok("مرحبا بك وجاري تحويلك إلى الرئيسية");
		exit();
	}elseif( isset($_POST['signin']) AND $_POST['type']=='employee' AND sign_employee($_POST['username'],$_POST['userpasword'])==TRUE ){
		
		header("refresh:3; url=items.php");
		ok("مرحبا بك وجاري تحويلك إلى الرئيسية");
		exit();
			
	}elseif(isset($_POST['signin'])){
		notok("الرجاء التحقق من اسم المستخدم والرقم السري");	
	}

?>



<form action="" method="POST" >
	<label>Username</label>
	<input type="text" name="username" required >

	<label>Password</label>
	<input type="password" name="userpasword" required >

	<label>Login as</label>
			<select name="type" required >
				<option value="" >Please select</option>
				<option value="student" >Student</option>
				<option value="employee" >Employee</option>
			</select>
			
	<input type="submit" name="signin"  value="Login" >
</form>
</div>
