<div class="centerdiv" >
		<h1>إضافة قطعة</h1>
<?php
	if(isset($_POST['go'])){

	$cafeteria_id	=	$_POST['cafeteria_id'];
	$ITEM_NAME			=	$_POST['ITEM_NAME'];
	$ITEM_PRICE			=	$_POST['ITEM_PRICE'];
	$category_id		=	(int)$_POST['category_id'];
	$ITEM_QUANTITY		=	(int)$_POST['ITEM_QUANTITY'];
	$ITEM_DWSCREPTION	=	addslashes($_POST['ITEM_DWSCREPTION']);
	
if (isset($_FILES) AND !empty($_FILES['ITEM_IMG']) ){
		
	$size 			= 	$_FILES['ITEM_IMG']['size'];   
	$path 			= 	$_FILES['ITEM_IMG']['name'];
	$ext 			= 	pathinfo($path, PATHINFO_EXTENSION);
	$rand 			=	rand(1,1000).time();
	$ITEM_IMG		=	$rand.".".$ext;
	
		
			if(is_uploaded_file($_FILES['ITEM_IMG']['tmp_name']) ) {
				$newPath = $upload_folder . $ITEM_IMG;
				if(move_uploaded_file($_FILES['ITEM_IMG']['tmp_name'],$newPath)) {	
			
				$sql	=	"INSERT INTO `items` (`ITEM_ID`, `cafeteria_id`, `ITEM_NAME`, `ITEM_PRICE`, `ITEM_DWSCREPTION`, `ITEM_QUANTITY`, `ITEM_IMG`,`category_id`) 
				VALUES (NULL, '$cafeteria_id', '$ITEM_NAME', '$ITEM_PRICE', '$ITEM_DWSCREPTION', '$ITEM_QUANTITY', '$ITEM_IMG', '$category_id') ";
				$connection->query($sql);
				ok("تم إضافة القطعة بنجاح وجاري تحويلك");
				header("refresh:3; url=admin.php?items");
				exit();
				}
			}
		
}


	
		
	}
?>

		
		<form action="" method="POST" enctype="multipart/form-data" >
		<label>الكافتيريا</label>
			  <select  name="cafeteria_id" required  >
				<option value="">الرجاء الإختيار من القائمة</option>
				<?php 
					$rescom	=	$connection->query("SELECT * FROM `cafeteria_information` ");
					while ($rowcom	=	mysqli_fetch_assoc($rescom))
						echo '<option value="'.$rowcom['CAFETERIA_ID'].'">'.$rowcom['CAFTERIA_USERNAME'].'</option>';
				?>
				
			  </select>
		<label>القسم</label>
			  <select  name="category_id" required  >
				<option value="">الرجاء الإختيار من القائمة</option>
				<?php 
					$rescom	=	$connection->query("SELECT * FROM `items_category` ");
					while ($rowcom	=	mysqli_fetch_assoc($rescom))
						echo '<option value="'.$rowcom['category_id'].'">'.$rowcom['category_title'].'</option>';
				?>
				
			  </select>
			
			<label>إسم القطعة</label>
			<input type="text" name="ITEM_NAME" required >
						
			<label>الوصف</label>
			<textarea name="ITEM_DWSCREPTION" required ></textarea>
			
			<label>السعر</label>
			<input type="text" name="ITEM_PRICE" required >
			
			<label>الكمية المتاحة</label>
			<input type="number" name="ITEM_QUANTITY" required >
			
			<label>صورة القطعة</label>
			<input type="file" name="ITEM_IMG" required >
			
			<input type="submit" name="go"  value="أضف" >
		</form>
		</div>
