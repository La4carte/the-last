<div class="centerdiv" >
		<h1>تأكيد التوصيل والتسليم</h1>
<?php
		$id		=	(int)$_GET['delivery'];
			update("orders","ORDER_ID",$id,'ORDER_STATE',"تم تسليم الطلب");
				ok("تم تأكيد التوصيل بنجاح");
				header("refresh:3; url=?orders");
				exit();		

?>
		</div>
