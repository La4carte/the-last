<div class="centerdiv" >
		<h1>تعديل قطعة</h1>
<?php
$id	=	$_GET['edititem'];
	if(isset($_POST['go'])){
	$cafeteria_id	=	$_POST['cafeteria_id'];
	$ITEM_NAME			=	$_POST['ITEM_NAME'];
	$ITEM_PRICE			=	$_POST['ITEM_PRICE'];
	$category_id		=	(int)$_POST['category_id'];
	$ITEM_QUANTITY		=	(int)$_POST['ITEM_QUANTITY'];
	$ITEM_DWSCREPTION	=	addslashes($_POST['ITEM_DWSCREPTION']);

		update("items","ITEM_ID",$id,'cafeteria_id',$cafeteria_id);
		update("items","ITEM_ID",$id,'category_id',$category_id);
		update("items","ITEM_ID",$id,'ITEM_NAME',$ITEM_NAME);
		update("items","ITEM_ID",$id,'ITEM_PRICE',$ITEM_PRICE);
		update("items","ITEM_ID",$id,'ITEM_QUANTITY',$ITEM_QUANTITY);
		update("items","ITEM_ID",$id,'ITEM_DWSCREPTION',$ITEM_DWSCREPTION);

if (isset($_FILES) AND !empty($_FILES['ITEM_IMG']) ){
		
	$size 			= 	$_FILES['ITEM_IMG']['size'];   
	$path 			= 	$_FILES['ITEM_IMG']['name'];
	$ext 			= 	pathinfo($path, PATHINFO_EXTENSION);
	$rand 			=	rand(1,1000).time();
	$ITEM_IMG		=	$rand.".".$ext;
	
		
			if(is_uploaded_file($_FILES['ITEM_IMG']['tmp_name']) ) {
				$newPath = $upload_folder . $ITEM_IMG;
				if(move_uploaded_file($_FILES['ITEM_IMG']['tmp_name'],$newPath)) {	
				update("items","ITEM_ID",$id,'ITEM_IMG',$ITEM_IMG);
				
				}
			}
		
		
}

				ok("تم تعديل القطعة بنجاح وجاري تحويلك");
				header("refresh:3; url=admin.php?items");
				exit();
	
		
	}
	
	
$sql	=	"select * from items where ITEM_ID='$id' ";
$result=	$connection->query($sql);
$row	=	mysqli_fetch_assoc($result);
?>

		
		<form action="" method="POST" enctype="multipart/form-data" >
			

			<label>الكافتيريا</label>
			  <select  name="cafeteria_id" required  >
				<?php 
				echo '<option value="'.$row['cafeteria_id'].'">'. valueIs("cafeteria_information","CAFETERIA_ID",$row['cafeteria_id'],"CAFTERIA_USERNAME").'</option>';
					$rescom	=	$connection->query("SELECT * FROM `cafeteria_information` ");
					while ($rowcom	=	mysqli_fetch_assoc($rescom))
						echo '<option value="'.$rowcom['CAFETERIA_ID'].'">'.$rowcom['CAFTERIA_USERNAME'].'</option>';
				?>
				
			  </select>
			<label>القسم</label>
			  <select  name="category_id" required  >
				<?php 
				echo '<option value="'.$row['category_id'].'">'. valueIs("items_category","category_id",$row['category_id'],"category_title").'</option>';
					$rescom	=	$connection->query("SELECT * FROM `items_category` ");
					while ($rowcom	=	mysqli_fetch_assoc($rescom))
						echo '<option value="'.$rowcom['category_id'].'">'.$rowcom['category_title'].'</option>';
				?>
				
			  </select>			
			<label>إسم القطعة</label>
			<input type="text" name="ITEM_NAME" value="<?php echo $row['ITEM_NAME'];?>" required >
						
			<label>الوصف</label>
			<textarea name="ITEM_DWSCREPTION" required ><?php echo $row['ITEM_DWSCREPTION'];?></textarea>
			
			<label>السعر</label>
			<input type="text" name="ITEM_PRICE" value="<?php echo $row['ITEM_PRICE'];?>" required >
			
			<label>الكمية المتاحة</label>
			<input type="number" name="ITEM_QUANTITY" value="<?php echo $row['ITEM_QUANTITY'];?>" required >
			
			<label>صورة القطعة</label>
			<input type="file" name="ITEM_IMG"  >
			
			<input type="submit" name="go"  value="تعديل" >
		</form>
		</div>
