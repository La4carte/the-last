<div class="centerdiv" >
		<h1>تعديل القسم</h1>
<?php
$id	=	(int)$_GET['editcategory'];

	if(isset($_POST['go'])){

				$category_title	=	$_POST['category_title'];
				update("items_category","category_id",$id,'category_title',$category_title);
				ok("تم تعديل القسم بنجاح وجاري تحويلك");
				header("refresh:3; url=admin.php?categories");
				exit();
	}
	
$sql	=	"select * from items_category where category_id='$id' ";
$result=	$connection->query($sql);
$row	=	mysqli_fetch_assoc($result);

?>

		<form action="" method="POST">
			<label>مسمى القسم</label>
			<input type="text" name="category_title" value="<?php echo $row['category_title'];?>" required >
			<input type="submit" name="go"  value="تعديل" >
		</form>
		</div>
