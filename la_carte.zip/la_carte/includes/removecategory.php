<div class="centerdiv" >
<h1>حذف قسم</h1>

<?php
		$id	=	(int)$_GET['removecategory'];
		delete("items_category","category_id",$id);
		header("refresh:3; url=admin.php?categories");
		ok("تم الحذف بنجاح");
		exit();
?>
</div>
