<div  style="margin-top:20px;">
<h1>قائمة الطلبات</h1>

		<table >
			<tr>
				<th>المشتري</th>
				<th>قائمة السلة</th>
				<th>الحالة</th>
				<th>تاريخ الطلب</th>
				<th>طريقة الدفع</th>
				<th>التوصيل</th>
				<th>أكد الإستلام</th>
			</tr>
<?php 
	$sql	=	"SELECT * FROM `orders` ORDER BY ORDER_ID DESC ";
	$result = 	$connection->query($sql);
	while($row 	=	mysqli_fetch_assoc($result)){
		if($row['user_type']=='student'){
			$table	=	"student_information";
			$name	=	"STUDENT_NAME";
			$row_id	=	"STUDENT_ID";
		}else{
			$table	=	"employee_information";
			$name	=	"EMPLOYEE_NAME";
			$row_id	=	"EMPLOYEE_ID";
		}

?>			
			<tr>
				<td><?php echo valueIs($table,$row_id,$row['user_id'],$name);?></td>
				<td><a href="?order=<?php echo $row['ORDER_ID'];?>">عرض السلة</a></td>
				<td><?php echo $row['ORDER_STATE'];?></td>
				<td><?php echo $row['ORDER_DATE'];?></td>
				<td><?php echo $row['PAY_METHOD'];?></td>
				<td>
					<?php if($row['user_type']=='employee' AND $row['ORDER_STATE']=='Receipt from your office' AND $row['DELIVRY_ID']==NULL){ ?>
						<a href="?delivered=<?php echo $row['ORDER_ID'];?>">تعيين عامل توصيل</a>
					<?php }elseif( $row['user_type']=='employee' AND $row['ORDER_STATE']=='Receipt from your office' AND $row['DELIVRY_ID']!=NULL){
							echo valueIs('delivry_information','DELIVRY_ID',$row['DELIVRY_ID'],'DELIVRY_NAME');
						}else{
						echo "لم يطلب خدمة التوصيل";	
						} ?>
				</td>
				<td>
				 <?php if ( $row['ORDER_STATE']!='تم تسليم الطلب') { ?>
					<a href="?delivery=<?php echo $row['ORDER_ID'];?>">تأكيد تسليم الطلبية</a>
				<?php } else {
					echo "تم تسليم الطلب";
				}?>	
					</td>
			</tr>
			
<?php } ?>

		</table>

</div>
