<div class="centerdiv" >
<h1>الإدارة</h1>

<center>
	<a href="admin.php?categories" ><button class="btn info">الأقسام</button></a>
	<a href="admin.php?items" ><button class="btn info">المنتجات</button></a>
	<a href="admin.php?orders" ><button class="btn info">الطلبات</button></a>
</center>

</div>
