<style>

table {
  border-collapse: collapse;
  width: 100%;
  
}

th, td {
  text-align: center;
  padding: 8px;
 border: 4px solid #ccc;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #4CAF50;
  color: white;
}

a {
text-decoration:none;
}

input, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 4px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 20px;
  font-weight:bold;
  font-family:arial;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  
}


.con {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-right:25%;
  margin-left:25%;
  margin-top:50px;
}


</style>
<div >
<h2>Cart</h2>
<?php

if(isset($_POST['go'])  ){
	$_SESSION['q']		=	array(); /* حفظ عدد القطع لكل عنصر */
	$_SESSION['final']	=	array(); /* حفظ القطع النهائية  وعدد قطعها بشكل نهائي */

		foreach($_POST AS $key=>$val){ /* عملية إضافة القطع */
			if($key!='go')
				array_push($_SESSION['q'],$val);
				
		}	
		$price_final	= array();    
		for($i=0; $i<count($_SESSION['cart']);$i++){ /*  عملية حفظ بالسيشن الفاينال بيحث الانديكس عبارة عن رقم العنصر والقيمة عن عدد القطع  */
			$temp_item	=	$_SESSION['cart'][$i];
			$temp_q		=	$_SESSION['q'][$i];
			$_SESSION['final'][$temp_item]=$temp_q;
			$priceAll	=	(float)valueIs("items","ITEM_ID",$temp_item,"ITEM_PRICE")*(int)$temp_q;
			array_push($price_final,$priceAll);
		}		 
				$_SESSION['final_price']	=	array_sum($price_final);	/* مجموع السلة من أري البرايس ومن ثم نحفظها بالسيشن */
		print_r($_SESSION['final_price']);
	header("Location: ?payment");	

}

?>


<form action="" method="POST" >
	<table  >
	  <tr >
		<th>Producte</th>
		<th width="120px">quantity</th>
		<th width="120px">Price</th>
		<th width="50px">Delete</th>
	  </tr>

	<?php 	
	if (isset($_SESSION['cart']) AND count($_SESSION['cart'])>0 ){ 
		foreach($_SESSION['cart'] AS $index=>$value){
	 ?>
	  <tr>
		<td><?php echo valueIs("items","ITEM_ID",$value,"ITEM_NAME");?></td>
		<td> 
		<?php $max_quantity	=	 valueIs("items","ITEM_ID",$value,"ITEM_QUANTITY") ;?>
			<input type="number" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name ="<?php echo $value;?>" value="1" max="<?php echo $max_quantity;?>" >
		</td>	
		<td><?php 	echo  valueIs("items","ITEM_ID",$value,"ITEM_PRICE");?></td>
		<td><a href="?delete=<?php echo $index;?>" >delete</a></td>
	  </tr>
<?php
 }

}  ?>	  
	</table> 

<input type="submit" name="go" value="Pay">
</form>



</div>
